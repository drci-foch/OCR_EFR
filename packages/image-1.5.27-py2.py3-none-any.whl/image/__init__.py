VERSION = (1, 5, 27)

default_app_config = 'image.apps.ImageConfig'
