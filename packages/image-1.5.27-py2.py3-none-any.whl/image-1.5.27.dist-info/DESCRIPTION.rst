Django application that provides cropping, resizing, thumbnailing, overlays and masking for images and videos with the ability to set the center of attention,


